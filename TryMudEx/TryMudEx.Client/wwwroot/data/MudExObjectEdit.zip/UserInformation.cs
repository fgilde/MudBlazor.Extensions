namespace Try.UserComponents
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.ComponentModel.DataAnnotations;

    public class UserInformation
    {
        public string Id { get; set; }
        [Required]
        [MinLength(3)]
        public string FirstName { get; set; }
        [Required]
        [MinLength(3)]
        public string LastName { get; set; }
        [Range(10, 100)]
        [Required]
        public int Age { get; set; }
        
        [Range(1, 3)]
        public Gender Gender { get; set; }

        public Address MainAddress { get; set; }
        public ICollection<Address> OtherAddresses { get; set; }
        public string Notice { get; set; }
        public TestModel SomeUnimportantTestModel { get; set; }
    }
}
