namespace Try.UserComponents
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.ComponentModel.DataAnnotations;
    
   public class TestModel
    {
        public string Property1 { get; set; }
        public string Property2 { get; set; }
    }
}
