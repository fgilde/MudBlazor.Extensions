namespace Try.UserComponents
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public enum Gender
    {
        PleaseSelect,
        Male,
        Female,
        Other
    }
}
