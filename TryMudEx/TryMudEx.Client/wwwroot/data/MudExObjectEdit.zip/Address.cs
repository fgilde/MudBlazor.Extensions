namespace Try.UserComponents
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.ComponentModel.DataAnnotations;

    public class Address
    {
        [Required]
        public string Street { get; set; }
        public string HouseNumber { get; set; }
        public string PostalCode { get; set; }
        [Required]
        public string City { get; set; }
        public override string ToString() => $"{Street} {HouseNumber}, {PostalCode} {City}";
    }
}
